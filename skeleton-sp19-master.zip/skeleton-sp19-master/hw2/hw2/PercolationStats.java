package hw2;

public class PercolationStats {

}
