package hw2;

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

}
