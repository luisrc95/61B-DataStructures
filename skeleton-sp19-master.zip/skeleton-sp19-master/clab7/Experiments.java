/**
 * Created by hug.
 */
public class Experiments {
    public static void experiment1() {
    }

    public static void experiment2() {
    }

    public static void experiment3() {
    }

    public static void main(String[] args) {
    }
}
